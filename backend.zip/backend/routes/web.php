<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AddOffreController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Admin\OffreController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\SearchOffreController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\SettingsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/test', function () {
    return view('admin.users');
});

Route::get('/', function () {
    return view('home');
})->name('home');

Route::get('/help',function () {
    return view('help');
})->name('help');

Route::get('/search',[SearchOffreController::class, 'index'])->name('search');

Route::middleware(['auth'])->group(function () {
    Route::get('/add',[AddOffreController::class, 'index'])->name('offre.add');
    Route::post('/add',[AddOffreController::class, 'store']);

    // Route::delete('/offre',[AddOffreController::class, 'destroy'])->name('offre.destroy');

    Route::get('/profile',[ProfileController::class, 'index'])->name('profile');

    Route::post('/chang_pswd',[SettingsController::class, 'EditPassword'])->name('user.password');
});

Route::middleware(['guest'])->group(function () {
    Route::get('/login',[LoginController::class, 'index'])->name('login');
    Route::post('/login',[LoginController::class, 'store']);

    Route::get('/register',[RegisterController::class, 'index'])->name('register');
    Route::get('/register/{choice}',[RegisterController::class, 'index']);
    Route::post('/register/{choice}',[RegisterController::class, 'store']);
});


Route::get('/detail/{offre_id}',[SearchOffreController::class, 'detail'])->name('detail');


// admin
Route::group(['prefix' => 'admin',  'middleware' => 'admin'], function()
{
    Route::get('/', function () {
        return view('admin.dashboard');
    })->name('dashboard');

    Route::post('/logout',[LogoutController::class, 'index'])->name('admin.logout');

    Route::get('/users',[UsersController::class, 'index'])->name('admin.users');

    Route::get('/users/{user}',[UsersController::class, 'detail'])->name('admin.users.detail');

    Route::get('/offers',[OffreController::class, 'index'])->name('admin.offers');

    Route::get('/offers/add',[OffreController::class, 'addform'])->name('admin.offers.add');
    Route::post('/offers/add',[OffreController::class, 'store']);
});

Route::post('/logout',[LogoutController::class, 'index'])->name('logout')->middleware('auth');