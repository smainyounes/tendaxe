<?php

namespace App\Models;

use App\Models\UserSecteur;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'etablissement_id',
        'nom',
        'prenom',
        'email',
        'password',
        'phone',
        'nom_entreprise',
        'wilaya',
        'commune',
        'secteurs',
        'type_user',
        'exp',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function offre()
    {
        return $this->hasMany(Offre::class);
    }

    public function usersecteur()
    {
        return $this->hasMany(UserSecteur::class);
    }

    public function secteur()
    {
        return $this->belongsToMany(Secteur::class, 'user_secteur');
    }

    public function etablissement()
    {
        return $this->belongsto(Etablissement::class);
    }
}
