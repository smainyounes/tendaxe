<?php

namespace App\Http\Controllers;

use App\Models\Offre;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class AddOffreController extends Controller
{
    public function index()
    {
        if(Auth::user()->type_user === "content"){
            return view('offers.add');
        }

        if(Auth::user()->type_user === "abonné"){
            return view('offers.add2');
        }

        return abort(404);
    }

    public function store(Request $request)
    {
        if(Auth::user()->type_user === 'content'){
            // validation
            $this->validate($request, [
                'titre' => 'required|max:255',
                'description' => 'required|max:1500',
                'date_pub' => 'required|date',
                'date_lim' => 'required|date',
                'secteur' => 'required|array',
                'statut' => 'required|max:255',
                'type' => 'in:national,international',
                'prix' => 'required|numeric',
                //'image' => 'required_if:description,value|mimes:jpeg,jpg,png|max:10000', // max 10000kb
                ]);
            
                $fileName = null;

            if ($request->hasFile('photo')) {
                $image      = $request->file('photo');
                $fileName   = time() . '.' . $image->getClientOriginalExtension();

                $img = Image::make($image->getRealPath());
                $img->resize(1200, 1200, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });

                $img->stream(); // <-- Key point

                // dd($fileName);
                Storage::disk('local')->put('public/' . $fileName, $img);
            }


            $offre = Offre::create([
                'user_id' => Auth::id(),
                'titre' => $request->titre,
                'statut' => $request->statut,
                'type' => $request->type,
                'wilaya' => Auth::user()->etablissement->wilaya,
                'commune' => Auth::user()->etablissement->commune,
                'prix' => $request->prix,
                'description' => $request->description,
                'date_pub' => $request->date_pub,
                'date_limit' => $request->date_lim,
                'img_offre' => $fileName,
            ]);

            $offre->secteur()->sync($request->secteur);

            return redirect()->route('profile');
        }
    }

    public function destroy(Request $request)
    {
        //dd($request);
        return abort(403);
        
        $offre = Offre::find($request->offre);

        if($offre->user_id != Auth::id()){
            return abort(403);
        }

        $offre->secteur()->detach();

        $offre->delete();

        return back()->with('status', 'offre supprimer');
    }
}
