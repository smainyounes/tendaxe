<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UsersController extends Controller
{
    public function index(Request $request)
    {
        $users = new User();

        if($request->has('keyword')){
            $users = $users->where('email', 'LIKE', "%{$request->keyword}%")
                    ->orWhere('nom', 'LIKE', "%{$request->keyword}%")
                    ->orWhere('prenom', 'LIKE', "%{$request->keyword}%")
                    ->orWhere('phone', 'LIKE', "%{$request->keyword}%");
        }

        if($request->has('type_user') && $request->type_user !== 'all'){

            $users = $users->where('type_user', '=' , $request->type_user);
        }else{
            $users = $users->where('type_user', '!=' , 'admin');
        }

        $users = $users->latest()->paginate(10);

        return view('admin.users', [
            'users' => $users,
        ]);
    }

    public function detail(User $user)
    {

        $etab = null;

        if($user->type_user === 'content' && $user->etablissement_id){
            $etab = $user->etablissement;
        }
        return view('admin.userdetail', [
            'user' => $user,
            'etab' => $etab,
        ]);
    }
}
