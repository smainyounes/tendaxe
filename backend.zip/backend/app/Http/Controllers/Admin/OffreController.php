<?php

namespace App\Http\Controllers\Admin;

use App\Models\Offre;
use App\Models\Adminetab;
use App\Models\Journalar;
use App\Models\Journalfr;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class OffreController extends Controller
{
    public function index(Request $resquest)
    {
        $offres = Offre::latest()->paginate(5);

        return view('admin.offers', [
            'offres' => $offres,
        ]);
    }

    public function addform()
    {
        return view('admin.add_offer');
    }

    public function store(Request $request)
    {
        // validation
        $this->validate($request, [
            'titre' => 'required|max:255',
            'description' => 'max:1500',
            'date_pub' => 'required|date',
            'date_lim' => 'required|date',
            'secteur' => 'required|array',
            'statut' => 'required|max:255',
            'type' => 'in:national,international',
            'prix' => 'required|numeric',
            'etab' => 'required|numeric',
            'journal_ar' => 'required|numeric',
            'journal_fr' => 'required|numeric',
            'photo' => 'required_if:description,value|mimes:jpeg,jpg,png|max:10000', // max 10000kb
            ]);
        
        // check if new jornal is sent
        if($request->journal_ar == 0){
            $id_ar = $this->AddJournal($request, "ar");
        }else{
            $id_ar = $request->journal_ar;
        }

        if($request->journal_fr == 0){
            $id_fr = $this->AddJournal($request, "fr");
        }else{
            $id_fr = $request->journal_fr;
        }

        // add new etab
        if($request->etab == 0){
            // create the new etablissement

            $this->validate($request, [
                'nom_etab' => 'max:255',
                'category' => 'required|max:255',
                'wilaya_etab' => 'required|max:255',
                'commune_etab' => 'required|max:255',
                'email_etab' => 'max:255',
                'fix' => 'max:255',
                'fax' => 'max:255',
                'logo' => 'mimes:jpeg,jpg,png|max:10000',
            ]);

            $fileName = null;

            if ($request->category === "AUTRE" && $request->hasFile('logo')) {
                $image      = $request->file('logo');
                $fileName   = time() . '.' . $image->getClientOriginalExtension();

                $img = Image::make($image->getRealPath());
                $img->resize(150, 150);

                $img->stream(); // <-- Key point

                // dd($fileName);
                Storage::disk('local')->put('public/logo/' . $fileName, $img);
            }

            if($request->category !== "AUTRE")
                $nom_etab = "$request->category $request->commune_etab de la wilaya $request->wilaya_etab"; 

            $etab = Adminetab::create([
                'nom_etablissement' => ($request->category === "AUTRE") ? $request->nom_etab : $nom_etab,
                'category' => $request->category,
                'wilaya' => $request->wilaya_etab,
                'commune' => $request->commune_etab,
                'email' => $request->email_etab,
                'fix' => $request->fix,
                'fax' => $request->fax,
                'logo' => $fileName,
            ]);

            // dd($etab);

            if(!$etab){
                // etab not inserted delete the img
                Storage::delete('public/logo/' . $fileName);

                return back()->with('error', 'etab not inserted');
            }

            $etab_id = $etab->id;
        }else{
            $etab_id = $request->etab;
        }

        $fileName = null;

        // upload offer img
        if ($request->hasFile('photo')) {
            $image      = $request->file('photo');
            $fileName   = time() . '.' . $image->getClientOriginalExtension();

            $img = Image::make($image->getRealPath());
            $img->resize(1200, 1200, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
            });

            $img->stream(); // <-- Key point

            // dd($fileName);
            Storage::disk('local')->put('public/' . $fileName, $img);
        }

        $offre = Offre::create([
            'user_id' => Auth::id(),
            'titre' => $request->titre,
            'statut' => $request->statut,
            'type' => $request->type,
            'wilaya' => $request->wilaya_etab,
            'commune' => $request->commune_etab,
            'prix' => $request->prix,
            'description' => $request->description,
            'date_pub' => $request->date_pub,
            'date_limit' => $request->date_lim,
            'img_offre' => $fileName,
            'adminetab_id' => $etab_id,
            'journalar_id' => ($id_ar == -1) ?? null,
            'journalfr_id' => ($id_fr == -1) ?? null,
        ]);

        $offre->secteur()->sync($request->secteur);

        return redirect()->route('admin.offers');
    
    }

    private function AddJournal($request, $lang)
    {
        $fileName = null;

        if($lang === "ar"){
            $this->validate($request, [
                'nom_journal_ar' => 'required|max:100',
                'logo_journal_ar' => 'required|mimes:jpeg,jpg,png|max:10000',
            ]);

            // upload logo
            if ($request->hasFile('logo_journal_ar')) {
                $image      = $request->file('logo_journal_ar');
                $fileName   = time() . '.' . $image->getClientOriginalExtension();
    
                $img = Image::make($image->getRealPath());
                $img->resize(200, 200, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
    
                $img->stream(); // <-- Key point
    
                Storage::disk('local')->put('public/journal/' . $fileName, $img);
            }else{
                return null;
            }

            $journal = Journalar::create([
                'nom' => $request->nom_journal_ar,
                'logo' => $fileName,
            ]);

            if($journal){
                return $journal->id;
            }else{
                return back()->with('error', 'try again');
            }
            
        }

        if($lang === "fr"){
            $this->validate($request, [
                'nom_journal_fr' => 'required|max:100',
                'logo_journal_fr' => 'required|mimes:jpeg,jpg,png|max:10000',
            ]);

            // upload logo
            if ($request->hasFile('logo_journal_fr')) {
                $image      = $request->file('logo_journal_fr');
                $fileName   = time() . '.' . $image->getClientOriginalExtension();
    
                $img = Image::make($image->getRealPath());
                $img->resize(200, 200, function ($constraint) {
                    $constraint->aspectRatio();
                    $constraint->upsize();
                });
    
                $img->stream(); // <-- Key point
    
                Storage::disk('local')->put('public/journal/' . $fileName, $img);
            }else{
                return null;
            }

            $journal = Journalfr::create([
                'nom' => $request->nom_journal_fr,
                'logo' => $fileName,
            ]);

            if($journal){
                return $journal->id;
            }else{
                return back()->with('error', 'try again');
            }
        }
    }
}
