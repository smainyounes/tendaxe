<?php $__env->startSection('title', 'Offres'); ?>
    
<?php $__env->startSection('content'); ?>
    <div class="container main">
        <h1 class="bold text-center">List d’annonces</h1>
        <div class="text-right">
            <button class="btn btn-primary">Ajouter Offre</button>
        </div>
        <div class="row">
            <div class="col-md-3">
                <form class="bg-white p-2 border mt-2" method="GET" action="<?php echo e(route('search')); ?>">
                    <div class="form-group">
                        <input class="form-control bg-light" type="text" name="keyword" placeholder="chercher">
                    </div>
                    <select name="wilaya" class="form-control mb-2 wil1 selectpicker" title="Region" data-live-search="true">
                    </select>
                    <select name="statut" class="form-control mb-2 selectpicker" title="statut" data-live-search="true">
                        <option value="Mise en demeure et résiliation" data-tokens="Mise en demeure et résiliation">Mise en demeure et résiliation</option>
                        <option value="Adjudication" data-tokens="Adjudication">Adjudication</option>
                        <option value="Vente aux enchères" data-tokens="Vente aux enchères">Vente aux enchères</option>
                        <option value="Infructuosité" data-tokens="Infructuosité">Infructuosité</option>
                        <option value="Annulation" data-tokens="Annulation">Annulation</option>
                        <option value="Attribution de marché" data-tokens="Attribution de marché">Attribution de marché</option>
                        <option value="Prorogation de délai" data-tokens="Prorogation de délai">Prorogation de délai</option>
                        <option value="Appel d'offres & Consultation" data-tokens="Appel d'offres & Consultation">Appel d'offres & Consultation</option>
                    </select>
                    <select name="secteur[]" class="form-control mb-2 selectpicker" multiple title="Secteur" data-live-search="true">
                        <?php if($secteurs): ?>
                            <?php $__currentLoopData = $secteurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sect->id); ?>" data-tokens="<?php echo e($sect->secteur); ?>" ><?php echo e($sect->secteur); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>                       
                    </select>
                    <select name="type" class="form-control mb-2 selectpicker" title="Type" data-live-search="true">
                        <option value="national" data-tokens="national">National</option>
                        <option value="international" data-tokens="international">Internation</option>
                    </select>
                    <hr>
                    <select class="form-control mb-2 selectpicker" title="Date de publication" data-live-search="false">
                        <option value="today">Ajourdhui</option>
                        <option value="week">Cette semaine</option>
                        <option value="month">Ce mois</option>
                        <option value="3months">derniers 3 mois</option>
                    </select>
                    <select class="form-control mb-2 selectpicker" title="Date limit" data-live-search="false">
                        <option value="today">Ajourdhui</option>
                        <option value="week">Cette semaine</option>
                        <option value="month">Ce mois</option>
                        <option value="3months">derniers 3 mois</option>
                    </select>

                    <button type="submit" class="btn btn-primary w-100">Chercher</button>

                </form>
            </div>
            <div class="col-md-9">
                <?php if($offres->count()): ?>
                    <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.offre','data' => ['exp' => $expired,'offre' => $offre]]); ?>
<?php $component->withName('offre'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['exp' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($expired),'offre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($offre)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                <?php else: ?>
                    <h3 class="text-center">Pas de resultat</h3>
                <?php endif; ?>

                <?php echo e($offres->links()); ?>

            </div>
        </div>
    </div>

    <script type="text/javascript">
        wilaya1(09);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/offers/search.blade.php ENDPATH**/ ?>