<?php $__env->startSection('title', 'profile'); ?>
    
<?php $__env->startSection('content'); ?>
    <div class="container main">
        <h1 class="bold text-center">Profile</h1>
        <div class="text-right">
            <a href="<?php echo e(route('offre.add')); ?>" class="btn btn-primary">Ajouter Offre</a>
        </div>

        <?php if(count($errors)>0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($error); ?>


                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        <div class="row mt-3 mb-5">
            <div class="col-md-3">
              <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">Liste Offres</a>
                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Parametres</a>
              </div>
            </div>
            <div class="col-md-9">
              <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">

                    <?php if($offres): ?>
                        <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="my-2">
                                <div class="bg-white px-3 pt-3 border rounded">
                                    <div class="row">
                                        <div class="col-9 col-md-10 bold">
                                            <?php echo e($offre->titre); ?>

                                        </div>
                                        <div class="col-3 col-md-2 text-right">
                                            <?php if($logo): ?>
                                                <img class="rounded-circle" src="<?php echo e(asset('storage/logo/' . $logo )); ?>" width="64px">
                                            <?php else: ?>
                                                <img class="" src="<?php echo e(asset('img/1.png')); ?>" width="64px">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                        <div class="mb-2">
                                            <span class="bold">Statut: </span>
                                            <?php echo e($offre->statut); ?>

                                        </div>
                                        <div class="mb-2">
                                            <span class="bold">Wilaya: </span>
                                            
                                            <?php echo e($offre->wilaya); ?>

                                        </div>
                                        <div class="my-3 d-flex">
                                            <span class="mx-auto mt-2"> <img src="img/icons/play.png"> <?php echo e($offre->date_pub); ?></span>
                                            <span class="mx-auto mt-2"> <img src="img/icons/stop.png"> <?php echo e($offre->date_limit); ?></span>
                                            <div class="ml-auto">
                                                <a href="<?php echo e(route('detail', $offre)); ?>" class="btn btn-sm btn-primary ">Detail</a>
                                                
                                            </div>
                                            
                                        </div>
                                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h3 class="text-center">Aucun offre</h3>
                    <?php endif; ?>
                    
                    <?php echo e($offres->links()); ?>

                    
                </div>
                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                    <div class="bg-white p-3">
                        <h3 class="text-center">Changer mot de passe</h3>
                        <form action="<?php echo e(route('user.password')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Ancient mot de passe</label>
                                <input class="bg-light form-control" type="password" name="old_password">
                            </div>
                            <div class="form-group">
                                <label for="">Nouveau mot de passe</label>
                                <input class="bg-light form-control" type="password" name="password">
                            </div>
                            <div class="form-group">
                                <label for="">repetez nouveau mot de passe</label>
                                <input class="bg-light form-control" type="password" name="password_confirmation">
                            </div>
                            <div class="text-right">
                                <button class="btn btn-primary px-4">Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
              </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/profile.blade.php ENDPATH**/ ?>