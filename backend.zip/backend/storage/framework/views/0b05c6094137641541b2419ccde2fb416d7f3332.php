<?php $__env->startSection('title', 'Detail Offre'); ?>
    
<?php $__env->startSection('content'); ?>
<div class="container main">
    <div class="row pt-5">
        <div class="col-md-3">
            <div class="text-center">
                <h6 class="bold mb-4">L’Annonceur:</h6>
                <?php if($expired): ?>
                    <img class="img-fluid mb-4" src="<?php echo e(asset('img/icons/lock3.png')); ?>">
                    <h6 class="bold mb-4">Réservé aux abonnés</h6>
                <?php else: ?>
                    <?php if($offre->user->type_user === "abonné"): ?>
                        <img class="img-fluid mb-4" src="<?php echo e(asset('img/user.png')); ?>">
                    <?php elseif($img === "default"): ?>
                        <img class="img-fluid mb-4" src="<?php echo e(asset('img/2.png')); ?>">
                        <h6 class="bold mb-4"><?php echo e($etab->nom_etablissement); ?></h6>
                    <?php elseif($img): ?>
                    <img class="img-fluid mb-4 rounded-circle" src="<?php echo e(asset('storage/logo/' . $img)); ?>">
                    <h6 class="bold mb-4"><?php echo e($etab->nom_etablissement); ?></h6>
                    <?php endif; ?>
                <?php endif; ?>
                
            </div>
            <div>
                <div class="mb-2">
                    <span class="bold">Statut: </span>
                    <?php echo e($offre->statut); ?>

                </div>
                <div class="mb-2">
                    <span class="bold">Type: </span>
                    <?php echo e($offre->type); ?>

                </div>
                <div class="mb-2">
                    <span class="bold">Wilaya: </span>
                    <?php if($expired): ?>
                        <img src="<?php echo e(asset('img/icons/lock.png')); ?>">
                        Réservé aux abonnés
                    <?php else: ?>
                        <?php echo e($offre->wilaya); ?>

                    <?php endif; ?>         
                </div>

                <?php if(!$expired && $etab): ?>
                    <?php if($etab->fix): ?>
                        <div class="mb-2">
                            <span class="bold">fix: </span>
                            <?php echo e($etab->fix); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($etab->fax): ?>
                        <div class="mb-2">
                            <span class="bold">fax: </span>
                            <?php echo e($etab->fax); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($etab->email): ?>
                        <div class="mb-2">
                            <span class="bold">Email ou siteweb: </span>
                            <?php echo e($etab->email); ?>

                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="mb-2">
                    <b>Date publication:</b>  <?php echo e($offre->date_pub); ?>

                </div>
                <div class="mb-2">
                    <b>Date d'échéance:</b>  <?php echo e($offre->date_limit); ?>

                </div>
                <div class="mb-2">
                    <b>Secteur</b>
                    <ul class="pl-2 mt-2" style="list-style: none;">
                        <?php $__currentLoopData = $offre->secteur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item->secteur); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="row mb-5">
                <div class="col-sm-11">
                    <h4 class="bold text-dark"><?php echo e($offre->titre); ?></h4>
                </div>
                <div class="col-sm-1">
                    <img class="img-fluid text-sm-right" src="<?php echo e(asset('img/icons/star.png')); ?>">
                </div>
            </div>
            <div class="">
                <div class="m-2">
                    <span>
                        <img class="mr-3" src="<?php echo e(asset('img/icons/indic.png')); ?>">
                        <b>Adress de retrait du cahier des charges: </b>

                        <?php if($expired): ?>
                            <img class="mx-2" src="<?php echo e(asset('img/icons/lock.png')); ?>">
                            Réservé aux abonnés
                        <?php else: ?>
                            bureau de marché de <?php echo e($etab->category); ?> de la wilaya <?php echo e($offre->wilaya); ?>

                        <?php endif; ?>
                    </span>
                </div>
                <div class="m-2">
                    <span>
                        <img class="mr-3" src="<?php echo e(asset('img/icons/dollar.png')); ?>">
                        <b>Prix d’cahier d’charge: </b>
                        <?php if($expired): ?>
                            <img class="mx-2" src="<?php echo e(asset('img/icons/lock.png')); ?>">
                            Réservé aux abonnés
                        <?php else: ?>
                            <?php echo e($offre->prix . " Dzd"); ?>

                        <?php endif; ?>
                        
                    </span>
                </div>
            </div>
            
            <?php if(!$expired && $offre->description): ?>
                <div class="my-4">
                    <p>
                        <?php echo e($offre->description); ?>

                    </p>
                </div>
            <?php endif; ?>
            
            <?php if($expired): ?>
            <div class="my-4">
                <img class="img-fluid" src="<?php echo e(asset('img/exemple.png')); ?>">
            </div>
            <?php endif; ?>
            <?php if(!$expired && $offre->img_offre): ?>
                <div class="my-4">
                    <img class="img-fluid" src="<?php echo e(asset('storage/' . $offre->img_offre)); ?>">
                </div>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <?php if($journal_ar || $journal_fr): ?>
                    <div class="row mt-4">
                        <?php if($journal_ar): ?>
                            <div class="col-md-4">
                                <img class="img-fluid" src="<?php echo e(asset('storage/journal/' . $journal_ar->logo)); ?>" alt="">
                            </div>
                        <?php endif; ?>

                        <?php if($journal_fr): ?>
                        <div class="col-md-4">
                            <img class="img-fluid" src="<?php echo e(asset('storage/journal/' . $journal_fr->logo)); ?>" alt="">
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
                <div class="my-4 text-center">
                    <button class="btn btn-lg btn-primary">
                        <b>Inscrivez-vous gratuitement</b>
                        <br>
                        avec 5 jours d’essai
                    </button>
                </div>
            <?php endif; ?>
           
            <div class="my-4">
                La date de remise des offres est donnée à titre indicatif, veuillez confirmer la date réelle auprès de l’annonceur
            </div>
        </div>
    </div>		
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/offers/detail.blade.php ENDPATH**/ ?>