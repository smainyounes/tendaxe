<?php $__env->startSection('title', 'Publier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container main">
        <h2 class="text-center bold">Publier une annonce</h2>
        <?php if(count($errors)>0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e($error); ?>


                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="bg-white p-3 border my-4">
            <form action="<?php echo e(route('offre.add')); ?>" method="POST" enctype= multipart/form-data>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Intitulé de Projet</label>
                    <input class="form-control bg-light" type="text" name="titre" required>
                </div>
                <div class="form-group">
                    <label for="">Description</label>
                    <textarea class="form-control bg-light" style="resize: none;" name="description" id="" rows="6"></textarea>
                </div>
                <div class="row">
                    
                    <div class="col-md-6 form-group">
                        <label for="">Date publication</label>
                        <input class="form-control bg-light" type="date" name="date_pub" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Date d'échéance</label>
                        <input class="form-control bg-light" type="date" name="date_lim" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Secteurs</label>
                        <select name="secteur[]" class="form-control mb-2 selectpicker" multiple title="Secteur" data-live-search="true" required>
                            <?php $__currentLoopData = App\Models\Secteur::All(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sect->id); ?>" data-tokens="<?php echo e($sect->secteur); ?>" ><?php echo e($sect->secteur); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Statut</label>
                        <select name="statut" class="form-control mb-2 selectpicker" title="statut" data-live-search="true" required>
                            <option value="Mise en demeure et résiliation" data-tokens="Mise en demeure et résiliation">Mise en demeure et résiliation</option>
                            <option value="Adjudication" data-tokens="Adjudication">Adjudication</option>
                            <option value="Vente aux enchères" data-tokens="Vente aux enchères">Vente aux enchères</option>
                            <option value="Infructuosité" data-tokens="Infructuosité">Infructuosité</option>
                            <option value="Annulation" data-tokens="Annulation">Annulation</option>
                            <option value="Attribution de marché" data-tokens="Attribution de marché">Attribution de marché</option>
                            <option value="Prorogation de délai" data-tokens="Prorogation de délai">Prorogation de délai</option>
                            <option value="Appel d'offres & Consultation" data-tokens="Appel d'offres & Consultation">Appel d'offres & Consultation</option>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Type</label>
                        <select name="type" class="form-control mb-2 selectpicker" required>
                            <option value="national" selected>national</option>
                            <option value="international">international</option>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Prix de caller de charge</label>
                        <input class="form-control bg-light" type="number" name="prix" required>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="">Fichier de publication</label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input bg-light" id="customFile" name="photo">
                            <label class="custom-file-label bg-light" for="customFile">Choisir fichier</label>
                        </div>
                    </div>
                </div>
                <div class="text-right">
                    <button class="btn btn-primary">Publier</button>
                </div>
            </form>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/offers/add.blade.php ENDPATH**/ ?>