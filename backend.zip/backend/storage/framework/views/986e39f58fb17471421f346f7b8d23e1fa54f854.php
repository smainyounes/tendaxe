<?php $attributes = $attributes->exceptProps(['offre' => $offre, 'expired' => $exp]); ?>
<?php foreach (array_filter((['offre' => $offre, 'expired' => $exp]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="my-2">
    <div class="bg-white px-3 pt-3 border rounded">
        <div class="row">
            <div class="col-9 col-md-10 bold">
               <?php echo e($offre->titre); ?>

            </div>
            <div class="col-3 col-md-2 text-right">
                <?php if($expired): ?>
                    <img class="" src="<?php echo e(asset('img/icons/lock2.png')); ?>" width="64px">
                <?php else: ?>
                    <?php if($offre->user->type_user === "admin"): ?>
                        <?php if($offre->adminetab->category !== "AUTRE"): ?>
                            <img class="" src="<?php echo e(asset('img/1.png')); ?>" width="64px">
                        <?php else: ?>
                            <img class="rounded-circle" src="<?php echo e(asset('storage/logo/'.$offre->adminetab->logo)); ?>" width="64px">
                        <?php endif; ?>
                    <?php elseif($offre->user->etablissement_id && $offre->user->etablissement->category === "AUTRE"): ?>
                        <img class="rounded-circle" src="<?php echo e(asset('storage/logo/'.$offre->user->etablissement->logo)); ?>" width="64px">
                    <?php else: ?>
                        <img class="" src="<?php echo e(asset('img/1.png')); ?>" width="64px">
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    
            <div class="mb-2">
                <span class="bold">Annonceur: </span>
                <?php if($expired): ?>
                    <img src="<?php echo e(asset('img/icons/lock.png')); ?>">
                    Réservé aux abonnés
                <?php else: ?>
                    <?php if($offre->user->type_user === "abonné"): ?>
                        <?php echo e($offre->user->nom_entreprise); ?>

                    <?php endif; ?>

                    <?php if($offre->user->type_user === "content"): ?>
                        <?php echo e($offre->user->etablissement->nom_etablissement); ?>

                    <?php endif; ?>

                    <?php if($offre->user->type_user === "admin"): ?>
                        <?php echo e($offre->adminetab->nom_etablissement); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class="mb-2">
                <span class="bold">Statut: </span>
                <?php echo e($offre->statut); ?>

            </div>
            <div class="mb-2">
                <span class="bold">Wilaya: </span>
                <?php if($expired): ?>
                    <img src="<?php echo e(asset('img/icons/lock.png')); ?>">
                    Réservé aux abonnés
                <?php else: ?>
                    <?php echo e($offre->wilaya); ?>

                <?php endif; ?>
            </div>
            <div class="my-3 d-flex">
                <span class="mx-auto mt-2"> <img src="<?php echo e(asset('img/icons/play.png')); ?>"> <?php echo e($offre->date_pub); ?></span>
                <span class="mx-auto mt-2"> <img src="<?php echo e(asset('img/icons/stop.png')); ?>"> <?php echo e($offre->date_limit); ?></span>
                <div>
                    <a href="<?php echo e(route('detail', $offre)); ?>" class="btn btn-sm btn-primary ml-auto">Detail</a>
                    <?php if(Auth::check() && Auth::user()->type_user === 'admin'): ?>
                        <button class="btn btn-sm btn-danger">Supprimer</button>
                    <?php endif; ?>
                </div>
            </div>
        
    </div>
</div><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/components/offre.blade.php ENDPATH**/ ?>