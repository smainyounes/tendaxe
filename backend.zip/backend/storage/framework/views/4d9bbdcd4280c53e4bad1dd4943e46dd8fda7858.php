<?php $__env->startSection('content'); ?>
    <h2 class="text-center">Dashboard</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>