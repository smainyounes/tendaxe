<?php $__env->startSection('title', 'Inscription'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container main">
        <h2 class="text-center pt-4 bold">Selectionnez votre catégorie</h2>
        <div class="row my-5 justify-content-center">
            <div class="col-md-5 mb-3">
                <div class="bg-white p-3 text-center mx-auto shadow" style="max-width: 322px;">
                    <img src="<?php echo e(asset('img/icons/etab.png')); ?>" alt="">
                    <h4 class="my-3 bold">Représentant d’un établissement</h4>
                    <p>appel
                        d’offre ou consultation, attribution
                        annulation mise à jour …</p>
                    <a href="<?php echo e(route('register') . '/2'); ?>" class="btn btn-primary py-2 w-100 mt-auto d-flex justify-content-between">
                        Action button 
                        <img src="<?php echo e(asset('img/icons/arrow.png')); ?>" alt="">
                    </a>
                </div>
            </div>
            <div class="col-md-5 mb-3">
                <div class="bg-white p-3 h-100 d-flex flex-column align-items-center mx-auto shadow" style="max-width: 322px;">
                    <img src="<?php echo e(asset('img/icons/user2.png')); ?>" alt="">
                    <h4 class="my-3 bold">Un abonné ordinaire</h4>
                    <p class="text-center">publier sous-traitance
                        ou des appels à des petit projet …</p>
                    <a href="<?php echo e(route('register') . '/1'); ?>" class="btn btn-primary py-2 w-100 mt-auto d-flex justify-content-between">
                        Action button 
                        <img src="<?php echo e(asset('img/icons/arrow.png')); ?>" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/auth/choice.blade.php ENDPATH**/ ?>