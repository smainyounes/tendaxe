<?php $__env->startSection('title', 'list users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="h3">List users</div>

    <div class="bg-white p-4 rounded">
        <form class="row" action="<?php echo e(route('admin.users')); ?>" method="GET">
            <div class="col-md-4">
                <input class="form-control" type="text" placeholder="search" name="keyword">
            </div>
            <div class="col-md-4">
                <select class="col-md-4 form-control" name="type_user" id="">
                    <option value="all" selected>tout</option>
                    <option value="abonné">abonné</option>
                    <option value="content">representant</option>
                </select>
            </div>
           <div class="col-md-4">
               <button class="btn btn-info">Search</button>
           </div>
        </form>
    </div>
    <div class="table-responsive">
        <?php if($users): ?>
        <table class="table table-striped table-hover">
            <thead>
              <tr>
                <th scope="col">Fullname</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Date inscription</th>
                <th scope="col">Date expiration</th>
                <th scope="col">user type</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('admin.users.detail', $user)); ?>">
                            <?php echo e($user->nom . ' ' . $user->prenom); ?>

                        </a>
                    </td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td><?php echo e($user->exp); ?></td>
                    <td><?php echo e($user->type_user); ?></td>
                    
                </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
            </tbody>
        </table>

        <?php echo e($users->links()); ?>

        <?php else: ?>
            <div class="h3 text-center">No users found</div>
        <?php endif; ?>
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/admin/users.blade.php ENDPATH**/ ?>