<?php $__env->startSection('title', 'user detail'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 p-3">
            <div class="container-fluid bg-white py-3">
                <h4>Info user</h4>
                <ul>
                    <li>fullname : <?php echo e("$user->nom $user->prenom"); ?></li>
                    <li>email : <?php echo e("$user->email"); ?></li>
                    <li>phone : <?php echo e("$user->phone"); ?></li>
                    <?php if(!$etab): ?>
                    <li>emplacement : <?php echo e("wilaya $user->wilaya , commune $user->commune"); ?></li>
                    <li>date exp : <?php echo e("$user->exp"); ?></li>
                    
                    <hr>

                    list etablissement abonné
                    <?php $__currentLoopData = $user->secteur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secteur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($secteur->secteur); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <?php if($etab): ?>
            <div class="col-md-6 p-3">
                <div class="container-fluid bg-white py-3">
                    <h4>Info etablissement</h4>
                    <?php if($etab->logo): ?>
                        <img class="rounded-circle" width="120px" src="<?php echo e(asset('storage/logo/'.$etab->logo)); ?>" alt="">
                    <?php endif; ?>
                    <ul>
                        <li>nom etablissement : <?php echo e("$etab->nom_etablissement"); ?></li>
                        <li>category : <?php echo e("$etab->category"); ?></li>
                        <li>emplacement : <?php echo e("wilaya $etab->wilaya , commune $etab->commune"); ?></li>
                        
                    </ul>
                    autre infos:
                    <ul>
                        <?php if($etab->fax): ?>
                            <li>fax : $etab->fax</li>
                        <?php endif; ?>
                        <?php if($etab->fix): ?>
                            <li>fix : $etab->fix</li>
                        <?php endif; ?>
                        <?php if($etab->email): ?>
                            <li>email ou site : $etab->email</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/james/Documents/work/tendaxe/backend/resources/views/admin/userdetail.blade.php ENDPATH**/ ?>