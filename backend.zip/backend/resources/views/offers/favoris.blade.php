@extends('layouts.layout')

@section('title', 'Favoris')

@section('content')
    <h1 class="bold text-center">List favoris</h1>
    
@endsection