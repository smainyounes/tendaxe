@extends('layouts.panel')

@section('content')
    <h2 class="text-center">Dashboard</h2>
@endsection