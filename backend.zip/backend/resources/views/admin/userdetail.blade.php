@extends('layouts.panel')

@section('title', 'user detail')

@section('content')
    <div class="row">
        <div class="col-md-6 p-3">
            <div class="container-fluid bg-white py-3">
                <h4>Info user</h4>
                <ul>
                    <li>fullname : {{ "$user->nom $user->prenom" }}</li>
                    <li>email : {{ "$user->email" }}</li>
                    <li>phone : {{ "$user->phone" }}</li>
                    @if (!$etab)
                    <li>emplacement : {{ "wilaya $user->wilaya , commune $user->commune" }}</li>
                    <li>date exp : {{ "$user->exp" }}</li>
                    
                    <hr>

                    list etablissement abonné
                    @foreach ($user->secteur as $secteur)
                        <li>{{ $secteur->secteur }}</li>
                    @endforeach
                    @endif
                </ul>
            </div>
        </div>
        @if ($etab)
            <div class="col-md-6 p-3">
                <div class="container-fluid bg-white py-3">
                    <h4>Info etablissement</h4>
                    @if ($etab->logo)
                        <img class="rounded-circle" width="120px" src="{{ asset('storage/logo/'.$etab->logo) }}" alt="">
                    @endif
                    <ul>
                        <li>nom etablissement : {{ "$etab->nom_etablissement" }}</li>
                        <li>category : {{ "$etab->category" }}</li>
                        <li>emplacement : {{ "wilaya $etab->wilaya , commune $etab->commune" }}</li>
                        
                    </ul>
                    autre infos:
                    <ul>
                        @if ($etab->fax)
                            <li>fax : $etab->fax</li>
                        @endif
                        @if ($etab->fix)
                            <li>fix : $etab->fix</li>
                        @endif
                        @if ($etab->email)
                            <li>email ou site : $etab->email</li>
                        @endif
                    </ul>
                </div>
            </div>
        @endif
    </div>
@endsection