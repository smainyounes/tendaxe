@extends('layouts.panel')

@section('title', 'list offers')

@section('content')
    <div class="text-center h3">List offers</div>

    <div class="bg-white p-3">
        @if ($offres)
            @foreach ($offres as $offer)
                <x-offre :exp="false" :offre="$offer" />
            @endforeach
            {{ $offres->links() }}
        @else
            <div class="h4 text-center">no offers found</div>
        @endif
    </div>
@endsection